=== WooCommerce Custom Payment Gateways ===
Contributors: royaltechbd
Tags: WooCommerce,Payment Gateways, Payment, Gateways
Donate link: http://royaltechbd.com/donate.html
Requires at least: 3.0.
Tested up to: 3.5.2
Stable tag: 2.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin just add Custom Payment Gateways for WooCommerce. 

== Description ==
This plugin just add Custom Payment Gateways for WooCommerce. So you can change name Custom Payment Gateways as per your requrements.


= More =
* Thank you for using our plugin.
* Vist the [blog post](http://royaltechbd.com/woocommerce-custom-payment-gateways) to know more.
* [Give a Rating & Write a Review](http://goo.gl/DmcVcG)

== Installation ==

1. Upload the plugin to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to WooCommerce > Setting > Payment Gateways Then Active & configure WooCommerce Custom Payment Gateways


== Frequently Asked Questions ==

Please [contact with us directly](http://royaltechbd.com/contact/) if you have any problem to install or use the plugin.

== Screenshots ==

1. Installed Plugin.
2. Configure Woocommerce > Settings > Payment Gateways.
3. Checkout Page.

== Changelog ==

= 1.0.0 =
* Initial Release


== Upgrade Notice ==

= 1.0.0 =
This version was tested with WooCommerce 2.0.13 and WordPress 3.5.2