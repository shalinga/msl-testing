jQuery(document).ready(function() {
	jQuery('#solostream-settings > ul').tabs();
	jQuery('#widget-tabs > ul').tabs();
	jQuery('#archive-tabs > ul').tabs();
	jQuery('#tabbed-cat > ul').tabs();
});