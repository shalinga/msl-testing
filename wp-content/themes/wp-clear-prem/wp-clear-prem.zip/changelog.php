*** WP-Clear Version 2.0 Changelog ***


05/09/2011 - Version 2.0
* First Logged release